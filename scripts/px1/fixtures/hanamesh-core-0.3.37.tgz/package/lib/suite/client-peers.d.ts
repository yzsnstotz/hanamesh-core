export interface ClientPeerFacts {
    readonly source: 'core-client-lease';
    readonly status: 'known' | 'unknown';
    readonly reason: string | null;
    readonly reactVersion: string | null;
    /** Opaque, process-local observation token; not a Host epoch or execution authorization. */
    readonly contextId: string;
}
type Lease = {
    ok: true;
    closed: Promise<void>;
    close: () => void;
};
type Result = {
    ok: false;
    error: {
        code: string;
        message: string;
        details: object;
    };
};
/** Fixed lease frame; Host repeats it while the lease is open so idle native forwarding keeps receiving bytes. */
export declare const CLIENT_PEER_FRAME: Uint8Array<ArrayBuffer>;
/** Below the 300 s Undici body timeout of the Electron forwarder. */
export declare const CLIENT_PEER_HEARTBEAT_MS = 30000;
/** Each authenticated Fetch invocation owns one live observation until its actual transport aborts. */
export declare class ClientPeerLeases {
    private readonly capable;
    private readonly salt;
    private revision;
    private disposed;
    private readonly active;
    constructor(capable: boolean);
    snapshot(): ClientPeerFacts;
    open(payload: unknown, signal: AbortSignal): Result | Lease;
    close(): void;
}
export {};
