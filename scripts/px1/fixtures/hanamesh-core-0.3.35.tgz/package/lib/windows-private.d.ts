export declare function privateWindowsDirectory(path: string): Promise<void>;
