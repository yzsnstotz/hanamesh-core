import type { SuiteManifest } from './types.js';
/** Public data, generated from this release's package metadata and profile during build. */
export declare const SUITE_MANIFEST: SuiteManifest;
export type { SuiteManifest, SuiteDeclaration, SuiteDeclarationRequest, SuiteInstalled, SuiteUpgrade, SuiteTarget, SuiteBlocked, SuiteInstallRelease } from './types.js';
export type { SuiteInstallOptions } from './install-command.js';
export { formatSuiteInstallCommand, suiteInstallArgs, createSuiteInstallRelease } from './install-command.js';
