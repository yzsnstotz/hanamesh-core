import type { SuiteInstallRelease } from './types.js';
export interface SuiteInstallOptions {
    readonly profile?: string;
    readonly registry?: string;
}
/** The sole executable suite installation definition. Consumers execute this argv verbatim. */
export declare function suiteInstallArgs(version: string, options?: SuiteInstallOptions): string[];
export declare function formatSuiteInstallCommand(version: string, options?: SuiteInstallOptions): string;
export declare function createSuiteInstallRelease(version: string, options?: SuiteInstallOptions): SuiteInstallRelease;
