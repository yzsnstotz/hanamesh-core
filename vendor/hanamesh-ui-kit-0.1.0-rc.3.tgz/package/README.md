# HanaMesh UI Kit · v0.1

**`@hanamesh/ui-kit@0.1.0-rc.3` · MOD-19 · 当前交付状态：`DELIVERED`（等用户验收）。**

代码、可安装产物、独立预览与测试随包交付。rc.1 的唯一必需缺口 **U02 官网视觉逐项对照** 已于 2026-09-12 回收判定完成（官网源码就在伞仓 `website/`）：4 处色值、2 处字体栈、圆角与焦点描边按官网实际声明修正，3 个 token 按官网值新增；对照表在 `docs/acceptance/U02-WEBSITE-CHECKLIST.md`。此版本不是 `ACCEPTED`，不能据此解锁 workspace；U05/U06 仍需用户亲眼看图签字。

## 打开与使用

最快看效果：直接打开 **`preview/standalone.html`**，不需要启动服务、联网或安装依赖。页面是 8 个组件和 27 个状态的静态验收样例，不是产品壳，也不代表真实业务状态。

开发环境已验证 Node **22.16.0** / npm **10.9.2**。构建工具锁定 TypeScript **5.8.3**，原始编译器 tarball 随仓提供，因此以下构建不依赖 npm registry：

```sh
npm ci --offline
npm run check
npm run test:mutations
npm run preview
```

`preview` 输出实际随机端口，打开其 `/preview/` 路径；也可 `npm run preview -- --port 4173`。预览服务器只监听回环地址。`npm run build` 同时生成 ESM、`.d.ts`、CSS、tokens JSON 和单文件离线预览。浏览器自动化另需 Python 与 `tests/requirements.txt` 中固定版本的 Playwright，以及本机 Chromium：

```sh
HM_CHROMIUM=/path/to/chromium npm run test:browser
```

本次浏览器测试使用 Linux Chromium，未冒称测试 macOS WKWebView、Tauri 或真实 DSH。浏览器对 HTTP 回环访问的环境拒绝有原始记录；已改为将**相同编译模块生成的离线 HTML**送入真实 Chromium DOM 测试，不修改浏览器策略。

## 固定产物消费

交付 tarball：`artifacts/hanamesh-ui-kit-0.1.0-rc.3.tgz`。将它复制到消费仓自己的 `vendor/`，再安装并提交生成的 lockfile：

```sh
npm install --save-exact --ignore-scripts ./vendor/hanamesh-ui-kit-0.1.0-rc.3.tgz
```

**不要**使用 workspace link、`npm link`、指向 ui-kit 源码的 alias 或跨插件私有 import。产物不带编译器，没有运行时依赖。UI kit 是浏览器 ESM + 原生 DOM 工厂，不是 React 组件或 DSH 插件本体；宿主 adapter 只需挂载返回的节点。CSS 由消费方显式加载，字体由宿主提供。

```ts
import { StatusBadge, UsageValue, Button } from '@hanamesh/ui-kit';
import '@hanamesh/ui-kit/styles.css'; // 支持 CSS import 的宿主构建器

const target = document.getElementById('content');
if (!target) throw new Error('Missing mount target');
target.replaceChildren(
  StatusBadge({ group: 'package', state: 'staged' }),
  UsageValue({ usage: { kind: 'unavailable', unit: 'tokens' } }),
  Button({ label: '重试', onClick: () => console.log('由宿主处理重试') }),
);
```

纯原生浏览器请由构建器解析包名，或像 `tests/consumer/` 一样复制**已安装包的 dist**并生成可直接打开的 HTML；不要让浏览器直接解析 npm 裸包名。

## 交付范围

| 组件 | 接口与行为 |
|---|---|
| `Button` | 原生按钮；默认不提交表单；禁用、加载、四种语义外观 |
| `TextField` | 关联 label 的原生输入框；hint/error、required、回调 |
| `SelectField` | 原生选择框；重复值和错误默认值显式拒绝 |
| `Checkbox` | 原生复选框；checked、indeterminate、表单重置 |
| `StatusBadge` | 五组 27 个状态；未知状态安全降级；文字/图标/边框同步映射 |
| `Notice` | 说明、运行、市场、注意提示；默认不主动播报 |
| `UsageValue` | reported / estimated / unavailable；保留来源，缺失永不变成 0 |
| `Divider` | 原生语义分隔线 |

状态规范见 [`docs/STATE_SPEC.md`](docs/STATE_SPEC.md)，完整 tokens 清单与覆盖方式见 [`docs/TOKENS.md`](docs/TOKENS.md)，接口约定见 [`docs/API.md`](docs/API.md)。

**v0.1 不含页面布局、六入口导航、路由、业务状态机、网络请求、授权判断、包安装、钱包或持久化。** `preview/` 和 `tests/consumer/` 只是明确标注的验收页，不会随 npm 包导出。

## 证据与后续门槛

完整矩阵与原始输出在 [`docs/acceptance/README.md`](docs/acceptance/README.md)。关键截图：

- [`U05：staged 与 active`](docs/acceptance/screenshots/U05-staged-vs-active.png)
- [`U06：unavailable 与 0`](docs/acceptance/screenshots/U06-unavailable-vs-zero.png)

**U02 的官网源码逐项核对已完成，模块仍待用户验收。** 来源、版本和逐项结论见 `docs/acceptance/U02-WEBSITE-CHECKLIST.md`。用户仍须亲眼确认 U05/U06 和视觉继承，才能登记 `ACCEPTED`；基础组件测试通过不替代用户签署。独立预览的本机 `file://` 打开曾被浏览器策略阻止，本轮修正后的预览只完成静态检查，见 `docs/acceptance/wave01-ui-acc-01-resolution-2026-09-12.md`。

`integration/` 提供只针对 ui-kit 的文档台账 patch，**未修改或推送用户文档仓**。不要用旧的 STATUS 快照覆盖其他并行模块进展。GitHub 没有创建或推送：本轮已检查连接，但暴露的接口没有写操作，环境也没有已认证的 `gh`。`scripts/publish-github.sh` 是可选的、默认创建私有仓的后续本地执行入口，不代表已经运行。

本项目未替权利人选择开源许可（`UNLICENSED`）；Phosphor 图标及编译器各自保留原许可，见 `THIRD_PARTY_NOTICES.md`。不分发字体文件。
