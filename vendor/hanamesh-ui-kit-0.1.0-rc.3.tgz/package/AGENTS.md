# HanaMesh UI Kit 工作约束

本仓只实现 MOD-19：tokens、8 个基础 DOM 组件、27 个状态及状态规范。v0.1 不含页面壳、导航、路由、业务数据或授权/安装/钱包/运行时 owner。不要为“通用性”扩充成组件框架。

开始先读 README、docs/STATE_SPEC.md、docs/acceptance/README.md 和 git status；保留其他人的未提交改动。更新代码后运行 `npm ci --offline && npm run check`，关键逻辑另跑 `npm run test:mutations`，可访问的浏览器跑 `npm run test:browser`。最终通过 `node scripts/verify-artifact.mjs` 检验 clean clone 和源码移走后的固定 tarball 消费（需要已提交的本地 git HEAD；会临时移动本仓，勿在其他进程写此仓时运行）。

两条绝不能回退：staged != active，unavailable != 0。reported 不是 verified；PASS 不是模块 ACCEPTED；owned/attached 不是 ready。未知事实安全降级。先写能抓住错误的断言，再确认变异真的让断言失败。

公共组件颜色只引用 tokens。保留 Phosphor 官方图形和许可，不造第二套图标。不要引入运行时依赖、私有插件类型、HTML 字符串注入、网络或持久化。不要拷贝字体文件。

U02 当前 PASS：已按伞仓官网 `website/src/styles/tokens.css` @ `e425c0b`（token 文件最后改动 `4ccdd03`）逐项核对，来源行号与客户端新增项见 `docs/acceptance/U02-WEBSITE-CHECKLIST.md`；官网源码变动后须重新核对。U02 PASS 不是模块 ACCEPTED，不能自签；用户看到并认可关键截图后才可进入最终验收。真实工作台视觉回归属于下游联合验收，不倒置成 ui-kit 开工依赖。

交付采用固定 tarball+digest+lockfile，不能 workspace link。包版本改动需要同步 consistency.json、预览、文档与消费模板。ZIP 不包含 node_modules；离线编译器是开发依赖，不进入运行时 npm 产物。

新远端默认 private，必须有当次授权；禁止覆盖已有远端、force push 或发布 npm。交付记录必须准确区分本地 commit / 本地 bundle / GitHub push，不能把工具权限 flags 当成写操作已完成。
