# Third-party notices

## Phosphor Icons

Six unmodified regular SVG path definitions: package, check-circle, warning, question, clock, x-circle. Copyright (c) 2023 Phosphor Icons, MIT License. The full notice is retained in `vendor/PHOSPHOR-LICENSE` and included in the npm package. Exact original bytes and SHA-256 hashes are in `vendor/phosphor/` and `vendor/phosphor-manifest.json`. The generated `src/icons.ts` embeds those paths with accessible decorative wrappers.

Source repository: https://github.com/phosphor-icons/core

The fetched raw URLs use the upstream main branch. This release pins the fetched **content by SHA-256**, not an invented upstream commit; upstream commit identity is unknown. Upstream file timestamps were 2023-03-05 for the SVGs. The notice is not an assertion that the whole current upstream repository was reviewed.

## TypeScript 5.8.3 (development only)

The compiler tarball in `vendor/typescript-5.8.3.tgz` was produced with `npm pack` from the preinstalled TypeScript 5.8.3 distribution in this environment. It is not claimed to be byte-identical to the registry tarball. It includes upstream LICENSE.txt, ThirdPartyNoticeText.txt and package metadata. TypeScript is licensed under Apache-2.0; see those original notices inside the tarball. Its lockfile integrity pins the delivered compiler bytes.

Source project: https://github.com/microsoft/TypeScript

This compiler is used only for build and test. It is excluded from the published/runtime UI kit tarball. There are no UI kit runtime dependencies.

## Fonts and project source

No font binaries are distributed or embedded. Font-family names in CSS are references to host-provided fonts, not a font license grant. The HanaMesh project code has not been assigned an open-source license by the user (`UNLICENSED`). Third-party notices above retain their respective terms.
