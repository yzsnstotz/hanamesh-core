# 公共 API · 0.1.0-rc.3

输出为 ES module / TypeScript 声明 / CSS。模块 import 无 DOM 副作用，可在 Node 中读状态和 tokens；调用组件工厂时必须有 `Document`，否则显式报错。不是 JSX/React 组件，不自动挂载或注册 custom elements。

## 八个工厂

所有参数均为对象；通用 `document?: Document` 用于 iframe 文档，`id?: string` 用于显式 ID。表单未传 ID 时自动生成，显式 ID 的唯一性由宿主保证。**不要把不可信或重复 ID 传入表单。**

| API → 返回节点 | 必填 | 可选与行为 |
|---|---|---|
| `Button` → HTMLButtonElement | `label` 非空 | variant=primary/secondary/runtime/market；type 默认 button；disabled/loading；loadingLabel；onClick(MouseEvent) |
| `TextField` → HTMLDivElement | `label` 非空 | name/value/placeholder；type=text/email/password/search/url/tel；hint/error；disabled/readOnly/required；autocomplete；onInput(value,event) |
| `SelectField` → HTMLDivElement | `label`, `options` 非空数组 | 每项 value/label/disabled；name/value/hint/error/required/disabled；onChange(value,event) |
| `Checkbox` → HTMLDivElement | `label` 非空 | name/value/checked/indeterminate/disabled/required/hint/error；onChange(checked,event) |
| `StatusBadge` → HTMLSpanElement | `group`, `state` | locale=zh-CN/en-US；showCode 默认 true；live=off/polite |
| `Notice` → HTMLDivElement | `title` 非空, `body` | tone=neutral/attention/runtime/market；live=off/polite/assertive |
| `UsageValue` → HTMLSpanElement | `usage` | locale=zh-CN/en-US |
| `Divider` → HTMLHRElement | 无 | document/id |

表单返回包装节点，里面包含原生控件及与其关联的标签/说明。需要读取值时 `field.querySelector('input')` 或 `field.querySelector('select')`；外部逻辑持有自己的 state，不将 UI 工厂当作应用 store。构造时给定的 value/checked 会同时设置原生 defaultValue/defaultChecked/defaultSelected，支持 form.reset()。Checkbox 的 indeterminate 是原生 property，不会通过 HTML 属性序列化。

所有可见字符串通过 DOM `textContent` 或控件 value 写入，不接受 HTML 字符串槽位。不自动发送数据、不注册 document 级长期事件或定时器。节点移出且宿主丢弃引用后，其局部事件可一起回收；宿主自己创建的订阅仍由宿主取消。

## 用量输入

```ts
import { UsageValue, normalizeUsage, formatUsage, type UsageInput } from '@hanamesh/ui-kit';
const missing: UsageInput = { kind: 'unavailable', unit: 'tokens', reason: '来源不可达' };
const zero: UsageInput = { kind: 'reported', value: 0, source: 'owner A', unit: 'tokens' };
const estimate: UsageInput = { kind: 'estimated', value: 1280, unit: 'tokens' };
UsageValue({ usage: missing }); // —，不是 0
normalizeUsage(JSON.parse('{"kind":"reported","value":null}')); // unavailable
formatUsage(estimate); // 保留 kind 与数值，增加 valueLabel = '≈ 1,280'
```

`UsageInput` 区分 number 与缺失：unavailable 禁止附带 value；reported/estimated 必须给 number。无类型 API 数据另有运行时校验，非法输入保留 unavailable。当前数值格式采用最多 12 个有效数字，不把极小正数裁剪成零。这里不是财务账本或任意精度金额库。

## 状态 / tokens 纯函数

`STATUS_CODES`, `STATUS_DEFINITIONS`, `UNKNOWN_STATUS` 不可变；`getStatus(group, state)` 对未知输入返回 UNKNOWN_STATUS；`statusLabel` / `statusDescription` 选择语言。`normalizeUsage` / `formatUsage` 接受 unknown 数据并作保守处理。`TOKENS` 不可变；`applyTheme(container, overrides)` 返回撤销函数。

所有官方导出都在 `src/index.ts` 与包的 exports 中声明。只读 `@hanamesh/ui-kit/states`、`/tokens`、`/tokens.json`、`/tokens.css`、`/styles.css` 也是固定公共入口。不要直接 import 内部 `dom` 或 `icons`。

## 插件接入边界

生命周期、版本、资源授权与来源真实性由业务 owner 决定，再把公共显示值传来。旧协议代码到新显示 code 的转换放在 owner adapter，不在 UI kit 里耦合插件的 BackendManifest 等私有类型。

React/Vue/其他宿主可在自己的挂载生命周期创建节点，卸载时移除；不要同时让框架 diff 该节点内部。渲染状态变化时替换整个 badge 或 usage 节点，不单独改 class 或 label。独立 iframe 需要把同一版本的 CSS 装到那个文档，然后通过 `{ document: iframe.contentDocument }` 创建节点。

本版本已验证“最小独立消费页”边界，不把它当成真实 DSH 插件 API 或 workspace 联验；接入具体宿主时仍遵循其现有挂载/卸载 API，不假造 DSH 方法。
