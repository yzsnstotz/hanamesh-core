# Design tokens · 官网核对值与客户端新增值

**状态：`WEBSITE_VERIFIED_2026-09-12`；U02 = PASS。** 逐项对照与来源行号见 `acceptance/U02-WEBSITE-CHECKLIST.md`（官网 `website/src/styles/tokens.css` @ `e425c0b`）。下表为当前值；标「客户端新增」的 token 官网没有对应声明。

## 完整公共清单

| token | 当前值 |
|---|---|
| `--hm-paper` | `#f7f3e8`（官网 tokens.css:2） |
| `--hm-paper-soft` | `#fffdf7`（官网 tokens.css:3） |
| `--hm-ink` | `#11110f`（官网 tokens.css:4） |
| `--hm-muted` | `#57564f`（官网 tokens.css:9） |
| `--hm-subtle` | `#e7e3d8`（客户端新增：表面底色） |
| `--hm-line` | `rgba(17, 17, 15, 0.14)`（官网 tokens.css:8） |
| `--hm-mint` | `#70d6b2`（官网 tokens.css:6） |
| `--hm-orange` | `#ff5a1f`（官网 tokens.css:5） |
| `--hm-runtime` | `#2457ff`（官网 tokens.css:7；焦点描边） |
| `--hm-font-display` | `"Archivo Variable", "Archivo", "Noto Sans SC Variable", "Noto Sans SC", "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", sans-serif`（官网 tokens.css:13，可变字体优先） |
| `--hm-font-body` | `"Noto Sans SC Variable", "Noto Sans SC", "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", system-ui, sans-serif`（官网 tokens.css:14） |
| `--hm-font-code` | `ui-monospace, SFMono-Regular, Menlo, Consolas, monospace` |
| `--hm-text-xs` | `0.75rem` |
| `--hm-text-sm` | `0.875rem` |
| `--hm-text-md` | `1rem` |
| `--hm-text-lg` | `1.125rem` |
| `--hm-text-value` | `2.5rem` |
| `--hm-leading` | `1.6` |
| `--hm-weight-normal` | `400` |
| `--hm-weight-strong` | `600` |
| `--hm-space-1` | `0.25rem` |
| `--hm-space-2` | `0.5rem` |
| `--hm-space-3` | `0.75rem` |
| `--hm-space-4` | `1rem` |
| `--hm-space-5` | `1.5rem` |
| `--hm-space-6` | `2rem` |
| `--hm-rule` | `1px` |
| `--hm-rule-strong` | `2px` |
| `--hm-rule-double` | `3px` |
| `--hm-radius` | `0.35rem`（官网 tokens.css:18） |
| `--hm-radius-pill` | `999px` |
| `--hm-control-height` | `2.75rem` |
| `--hm-icon-size` | `1.125rem` |
| `--hm-focus-width` | `2px` |
| `--hm-focus-offset` | `4px`（官网 base.css:33） |
| `--hm-disabled-opacity` | `0.58` |


## 覆盖而不改包

```ts
import { applyTheme } from '@hanamesh/ui-kit';
const undo = applyTheme(container, {
  '--hm-paper': '#fffaf0',
  '--hm-mint': '#c0e5cc',
  '--hm-orange': '#eead72',
  '--hm-radius': '0.625rem',
});
// 容器卸载或取消主题时：
undo();
```

也可在自己的 CSS 容器上声明同名 custom properties。组件本身不固定具体色值；颜色、边框、字体与间距来自 tokens。只有 `tokens.css` 提供 `:root` 默认变量，不注入全局 body/reset。主题修改不会改变状态语义、图标或 canonical 标签。override 由宿主管理，不读取或写入 localStorage。

`applyTheme` 先检查全部键名与非空字符串，再统一应用；未知键直接抛错，避免写入一半。返回的撤销函数可重复调用，保存并恢复已有 inline 值与 priority，不覆盖其后由别的 owner 修改的不同值。**不做不可信 CSS 安全校验或品牌色自动对比度校验**；只接受宿主可信配置，白标颜色仍要自行运行对比度测试。不要将未验证的远端任意 CSS 直接传入。

## 字体与证据限制

本包不加载 Google Fonts，不发起网络请求，不包含字体文件。宿主按许可提供 Archivo / Noto Sans SC；未提供时按声明的无衬线栈回退。本次截图在 Linux 实际用了 **Noto Sans CJK SC**，由 Chromium CSS.getPlatformFontsForNode 实测，不是假称 Archivo 已加载。字形、字重和 macOS WKWebView 度量须在真实宿主重新核对。

默认主题的七个实际文本/背景组合经 Chromium 测得 ≥ 4.5:1，结果见 browser-results.json；这不覆盖所有用户自定义主题。官网来源仅适用于 `acceptance/U02-WEBSITE-CHECKLIST.md` 明列的对应声明；其余组件 token 仍是客户端新增值。
