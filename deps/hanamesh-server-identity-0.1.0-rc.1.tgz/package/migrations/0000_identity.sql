-- Owned module: srv-identity. Execute with the HOST migration runner and DDL role.
-- The host owns BEGIN/COMMIT, locking and checksummed ledger. This file owns none of them.
-- Deliberately fail on pre-existing schemas: no silent adoption of an unverified schema.
-- Auth ids are uuid with a database default: Better Auth 1.7.4 `generateId: 'uuid'` on pg generates no id itself.
CREATE SCHEMA identity_auth;
CREATE SCHEMA identity;
REVOKE ALL ON SCHEMA identity_auth FROM PUBLIC;
REVOKE ALL ON SCHEMA identity FROM PUBLIC;

CREATE TABLE identity_auth."user" (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, email text NOT NULL UNIQUE,
  email_verified boolean NOT NULL DEFAULT false, image text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE identity_auth.session (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES identity_auth."user"(id) ON DELETE CASCADE,
  token text NOT NULL UNIQUE, expires_at timestamptz NOT NULL, ip_address text, user_agent text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX session_user_idx ON identity_auth.session(user_id);
CREATE INDEX session_expiry_idx ON identity_auth.session(expires_at);
CREATE TABLE identity_auth.account (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES identity_auth."user"(id) ON DELETE CASCADE,
  account_id text NOT NULL, provider_id text NOT NULL, access_token text, refresh_token text, id_token text,
  access_token_expires_at timestamptz, refresh_token_expires_at timestamptz, scope text, password text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX account_provider_subject_idx ON identity_auth.account(provider_id, account_id);
CREATE INDEX account_user_idx ON identity_auth.account(user_id);
CREATE TABLE identity_auth.verification (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), identifier text NOT NULL, value text NOT NULL, expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX verification_identifier_idx ON identity_auth.verification(identifier);

CREATE TABLE identity.deployment (
  singleton integer PRIMARY KEY CONSTRAINT deployment_singleton_check CHECK (singleton = 1),
  deployment_id text NOT NULL UNIQUE, auth_issuer text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE identity.principal (
  id uuid PRIMARY KEY, deployment_id text NOT NULL REFERENCES identity.deployment(deployment_id),
  display_name text NOT NULL CONSTRAINT principal_name_check CHECK (char_length(display_name) BETWEEN 1 AND 120),
  status text NOT NULL DEFAULT 'active' CONSTRAINT principal_status_check CHECK (status IN ('active','disabled')),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX principal_deployment_id_idx ON identity.principal(deployment_id, id);
CREATE TABLE identity.external_identity (
  deployment_id text NOT NULL, issuer text NOT NULL, subject text NOT NULL, principal_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (deployment_id, issuer, subject),
  FOREIGN KEY (deployment_id, principal_id) REFERENCES identity.principal(deployment_id, id),
  CONSTRAINT external_identity_issuer_check CHECK (char_length(issuer) BETWEEN 1 AND 512),
  CONSTRAINT external_identity_subject_check CHECK (char_length(subject) BETWEEN 1 AND 1024)
);
CREATE INDEX external_identity_principal_idx ON identity.external_identity(principal_id);
REVOKE ALL ON ALL TABLES IN SCHEMA identity_auth, identity FROM PUBLIC;
