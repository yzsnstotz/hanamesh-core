# 迁移元数据状态

本目录只记录状态：本交付环境未安装 Drizzle CLI，所以没有伪造 `_journal.json` 或 snapshot。

`../0000_identity.sql` 是已纳入版本的模块 SQL；`src/database/schema.ts` 对应同一七张表。部署仍使用宿主现有 migration runner 和 checksum ledger，不由 Drizzle CLI 运行第二套迁移。

后续需要 schema diff 时，输入限定为本模块的 `src/database/schema.ts`，输出限定为本模块迁移目录；先在两个独立空库验证，并确认 sibling_module 的 sentinel 保留。不得凭全库“最新快照”删除兄弟模块的schema/table。
