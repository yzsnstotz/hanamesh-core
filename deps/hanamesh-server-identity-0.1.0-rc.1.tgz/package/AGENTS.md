# HanaMesh 服务端研发总则

以 Fastify 为模块宿主、PostgreSQL + Drizzle 为数据基线，新建 HanaMesh 服务端与业务 schema，复用成熟认证、存储和链 SDK，不继承旧后台的整套耦合。一个实际服务模块默认一个独立 repo，一次用 Codex 或 Claude 原生编排交付一个范围明确、可安装进宿主并验证的版本；内部小步验证，不设重度 Meridian 流程。模块只拥有自己的 API、数据和迁移，跨模块用公开契约；产品仓只组合固定版本，首版可单进程单库，不一模块一微服务。授权由资源端检查，部署与迁移由获授权入口执行；不向客户端泄露管理凭据，不默认热换服务模块，不让 Shared 同步私有数据。开发前查 learning，交付时补问题、失败尝试、有效解法、版本与回归证据；不越仓写入，不自动访问生产、迁移旧数据或执行真实资金操作。

本地执行时先读文档仓 STATUS.md 与当前模块 KICKSTART，沿用 MODEL_POLICY.md 的默认模型；依赖已由用户验收才开工，一个主 agent 负责到底，独立模块按用户派发并行且隔离环境；状态和产物只写 STATUS.md，本地 commit，不因收尾自动 push；工具名不同可直接读 laws／learnings 文件，不新建编排层。


---

# 本仓写入与交付边界

本仓只归属 srv-identity，当前 `0.1.0-rc.1` / PARTIAL。先读 README、docs/acceptance/AC-24.md、docs/handoff/NEXT_AGENT.md。不要把示例宿主、内存测试或noCheck输出写成真正薄宿主/认证/PG验收。

源码位置 src/，迁移只含 identity、identity_auth；禁止修改兄弟schema、宿主ledger、DSH、钱包或支付模块。业务写入有宿主executor必须原样使用、不得连接池自取；原子事实与顺序边界见consistency.json。未输入明确隔离DB授权时不得执行test:real；不得安装系统包、启Docker或接生产资源来绕过。

用户在本次任务明确授权尝试在 yzsnstotz 下新建仓库；优先private，仅限hanamesh-server-identity，不可把不相关仓库当替代目标。本次工具没有建仓能力，所以没有远端创建/push。后续实际操作仍核对账户、权限、目标和秘钥扫描。

只改总文档STATUS里的srv-identity条目及自己的checkpoint/阻塞/候选产物，不解锁下游。外部消费者锁定tarball；正式验收之前不标DELIVERED/ACCEPTED。
