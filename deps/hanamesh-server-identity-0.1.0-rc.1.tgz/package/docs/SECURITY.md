# 安全与数据库部署边界

## 本版本边界

只有 Better Auth 邮箱／密码路径，没有第二套认证系统；密码散列和凭据存储由成熟库负责。钱包地址、header、前端 profile 字段不能直接成为主体。相同邮箱／地址字符串不能触发业务主体合并。`accountLinking` 关闭，未暴露账号绑定端点。

业务稳定键 `identity.principal.id` 与认证账户表完全分开；`identity.external_identity` 的复合主键为 deployment/issuer/subject，外键同时含 deployment/principal_id。删除/重建认证用户不会自动认领旧主体；任何未来迁移或账户合并必须有单独授权流程。

主体初次映射采取**验证会话之后懒创建**，principal+mapping 同事务。认证账户先存在而业务映射尚未生成是允许状态：它不授予业务资源权限；首次真正访问时建立映射，失败时接口关闭。认证库用户与业务主体不构成伪装的跨框架原子提交。

Cookie 以 HttpOnly、SameSite=Lax 使用；HTTPS时Secure。正式环境默认强制HTTPS。关闭session cookie cache和自动session refresh，保护接口逐请求验证实际服务端会话。`VerifiedActor` 是已验证当前请求的短期能力，最长30秒；不为并发中的操作承诺线性化撤销，也不得跨请求缓存。

CSRF/Origin检查保持开启，写接口还做精确Origin+JSON检查。HTTP authority来自固定配置，不来自Host/转发头；IP取自宿主 `request.ip`，宿主不可 `trustProxy:true` 信任任意来源。只在确定反代边界时设置明确代理白名单。

内存限流只适用于当前单进程slice，不宣称防分布式攻击。多个副本或公开大规模注册需要共享入口限流/反自动化策略。尚无邮箱验证、密码找回或MFA；默认关闭注册，不宜未决策就公开接收真实用户。

## 迁移执行归宿主

`src/database/schema.ts` + `migrations/0000_identity.sql` 是模块迁移**内容**。`getIdentityMigrations()` 提供模块id、SQL与SHA-256，**不执行迁移**，也不新建独立ledger。已有 `hanamesh-server` 负责授权DDL角色、事务、advisory lock、checksum ledger、升级顺序。

附件提及的宿主锁 `72401303`、`hanamesh_migrations.sbase` 保持归宿主；本模块不会自行读写它们。实际宿主接口不可见，所以对接形状必须由取得宿主代码后的agent核实。不得捏造已对接事实或更换一个“相似宿主”。

SQL只创建 `identity_auth`/`identity` 及七张表，不删除兄弟模型；已存在同名schema会失败，不静默 `IF NOT EXISTS` 接管未知旧数据。SQL不包含BEGIN/COMMIT，它们由宿主包围。升级前先备份并检查checksum；正式回退采用部署层前滚修复，不提供DROP业务表脚本。

本候选手工纳入了与官方数据库模型对应的SQL和Drizzle定义；**未运行Drizzle CLI生成schema或snapshot**。`migrations/meta/README.md` 明确没有伪造snapshot/journal。未来生成需只输入本模块schema并审查差异，不做全库推导删表。

## 运行角色建议（由授权部署人按宿主角色名执行）

以下是权限方案，不由模块请求处理器执行；不要把真实密码写进SQL、文档或代码仓：

```sql
-- 在隔离部署中用已存在的 hanamesh_runtime 举例；实际角色、DB名称由薄宿主配置。
REVOKE CREATE, TEMPORARY ON DATABASE YOUR_DATABASE FROM PUBLIC;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT CONNECT ON DATABASE YOUR_DATABASE TO hanamesh_runtime;
GRANT USAGE ON SCHEMA identity_auth, identity TO hanamesh_runtime;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA identity_auth TO hanamesh_runtime;
GRANT SELECT, INSERT ON identity.deployment, identity.principal, identity.external_identity TO hanamesh_runtime;
GRANT UPDATE ON identity.principal TO hanamesh_runtime;
```

运行角色不能是超级用户、库/owned-schema/table所有者、不能有CREATEDB/CREATEROLE/BYPASSRLS/REPLICATION或能切换到DDL角色的成员权限。其继承/SET ROLE关系还需宿主管理员审计；启动预检并不是数据库访问控制的替代品。部署授权与对整个库/公共schema的权限调整影响其他模块，须由宿主统一决定，不可让本模块私自改。

运行代码只SELECT/INSERT/UPDATE业务数据，关闭时只结束自己拥有的pool。第三方认证库事务是独立认证请求；跨业务模块事务传入固定 `SqlExecutor`，本模块不另开pool、不release外部连接。传入裸pool而不是固定transaction client是宿主编程错误，类型上的query方法不等于已开启数据库事务。

## 崩溃一致性声明

`consistency.json` 明确两组：主体+映射、认证用户+credential；两边界：session持久化→登录成功cookie、撤销持久化→登出成功cookie清理。auth适配器配置transaction=true，**实际事务支持尚需固定版本实测**；若被忽略/不支持，X02必须失败并阻塞发布，不能删掉此组。

test/real在授权隔离库里使用真正子进程SIGKILL，注入器属于test，不给生产代码增加可远程触发的崩溃开关。X03临时改副本使成功response先于数据库操作，检测不安全残留。它不证明断电、磁盘故障或所有可能竞态安全。

## 秘密处理与后续安全检查

包内没有实际DB凭据、认证密钥、会话cookie或用户数据；测试字符串均是合成夹具。日志只记录脱敏body、错误码、测试结果，不记录Cookie／Set-Cookie／密码／连接串。发布前需对真实已解析依赖图做漏洞检查、冻结lockfile、验证secret轮换和部署日志策略。本次不声称已通过安全审计。
