# HanaMesh · srv-identity

**版本：`0.1.0-rc.1` · 状态：`PARTIAL` · 日期：2026-09-12。**

这是独立身份模块的代码交付包，不是仅有方案的脚手架；但它也**不是已通过真实认证、数据库和薄宿主联调的正式交付版本**。当前环境无法下载依赖、没有 PostgreSQL，也无法读取指定的私有薄宿主。不得把本候选包登记成 `DELIVERED` / `ACCEPTED`，不得据此解锁下游。

## 本次已经写入并可检查的内容

- 单一 Web2 登录路径：Better Auth 邮箱／密码接入、登出、数据库会话验证；不自写密码哈希或 OAuth。
- 单独的 `identity` 业务主体与 `identity_auth` 认证表。主体由 `deployment_id + issuer + subject` 明确映射，不用邮箱／钱包／认证表主键冒充永久业务身份。
- 浏览器安全 DTO、精确错误码、通用资源／动作 guard；匿名、伪造主体和他人资源默认拒绝。
- 模块 SQL、Drizzle schema、运行角色预检、事务写入接口；**迁移执行仍由已有薄宿主部署流程负责**。
- 可直接执行的离线测试、变异测试、显式授权后可运行的真实 DB/API/SIGKILL 测试脚本，以及独立 tarball、Git bundle、状态补丁与交接说明。

## 已执行和没有执行的边界

| 检查 | 本次事实 |
|---|---|
| 离线功能／负测／SQL执行器与路由夹具 | **108/108 PASS**，Node 22.16.0；`artifacts/offline-tests.tap` |
| 三种错误的变异测试 | **3/3 被检测到**；每种原始测试 exit 0、变异后 exit 1；`artifacts/mutations/` |
| 不依赖第三方运行库的业务逻辑严格类型检查 | PASS；TypeScript 5.8.3，环境内 `@types/node` 25.1.0；见 `artifacts/build-evidence.json` |
| 全模块 JavaScript / `.d.ts` 输出 | 仅以 `tsc --noCheck` 产生候选适配层产物；**不能称为全量类型检查通过** |
| 目标版本依赖安装、完整编译、真实 Fastify/Better Auth/PG | BLOCKED；没有假造依赖 lockfile，也没有将 fixtures 记为 REAL_API/REAL_DB |
| 真正的宿主 tarball 装载与移走模块源码验证 | BLOCKED；没有取得 `hanamesh-server` 源码／锁定产物 |
| 远端仓库 | 没有创建或 push；见 `docs/handoff/GITHUB.md` |

完整验收矩阵：`docs/acceptance/AC-24.md`。`docs/handoff/NEXT_AGENT.md` 是下一位执行 agent 的直接入口。

## 版本与复现

| 项 | 目标／候选固定版本 | 本次运行 |
|---|---|---|
| Node | 24.13.1 | 22.16.0（仅离线检查） |
| pnpm | 10.33.0 | 未安装 |
| Fastify | 5.12.3（沿用已验收薄宿主约定） | 未安装／未运行 |
| PostgreSQL | 17.6 | 未安装／未运行 |
| Drizzle ORM | 0.45.2 | 未安装／未运行 |
| pg | 8.23.0 | 未安装／未运行 |
| Better Auth | 1.7.4（文档候选，需实际安装确认） | 未安装／未运行 |
| `@better-auth/drizzle-adapter` | 1.7.4（文档候选） | 未安装／未运行 |
| TypeScript | 5.9.3 | 5.8.3（业务逻辑检查） |

直接依赖采用精确版本不等于整个传递依赖图已经锁定。**当前没有 `pnpm-lock.yaml`**，因为网络无法解析 npm registry；下一台机器首次成功解析后要审查并提交真实 lockfile，再把 CI 安装改为 `--frozen-lockfile`。不要手写 integrity 或复制无关项目 lockfile。

### 无需安装依赖即可复跑本次离线证据

本交付包包含已输出的 `dist/`，下列命令没有外部安装、数据库连接或 DDL：

```bash
node --test test/*.test.mjs
node scripts/mutations.mjs
node scripts/preflight.mjs   # 配置／依赖不全时 exit 2 是预期，不代表服务验收成功
```

`dist` 与源文件对应，但身份框架适配层尚未经过目标依赖的完整类型检查；正式集成前必须重新构建，不能直接把这次候选 JS 当作已验收二进制。

### 在已授权的开发机上完成全量检查

先切到 Node 24.13.1、pnpm 10.33.0；下面的安装和真实数据库操作**本次没有执行**。

```bash
pnpm install --no-frozen-lockfile  # 首次成功解析后审查并保存生成的 pnpm-lock.yaml
pnpm build
pnpm test
pnpm test:mutations
```

真实验收脚本只接受本机 PostgreSQL `/postgres` 维护库；会生成随机名称的两个隔离数据库和角色，再在 finally 中只清理自己创建的资源。**必须确认你允许在此本机测试实例创建／删除数据库与角色；不得提供生产连接串。**

```bash
export IDENTITY_ALLOW_TEST_DB=CREATE_AND_DROP_LOCAL_ONLY
# 通过终端／安全凭据管理器设置，不把真实值提交到仓库：
export IDENTITY_TEST_ADMIN_URL='postgresql://YOUR_LOCAL_ADMIN:YOUR_PASSWORD@127.0.0.1:5432/postgres'
pnpm test:real
```

预期证据写到 `artifacts/real-results.json`。脚本包含真实注册／登录／登出／过期、A/B 权限隔离、两空库迁移、运行 DDL 拒绝、宿主事务回滚及变异、`kill -9` 中断测试。**这些是已写好的待执行测试，不是本次已经通过的事实。** 若固定版本 API／测试注入点发生偏差，应修实现或注入器并保留失败记录，不能删除验收项。

即使这组测试通过，**I01 仍须进入真正的 `hanamesh-server` 仓库完成**；本包的 `examples/server.mjs` 只是样例，不替代已验收薄宿主。

## 配置与本地样例

复制 `.env.example`，设置你的**受限运行角色**、独立随机密钥、稳定 deployment/issuer、精确 Origin。运行角色不能是 DB owner、superuser，不能拥有 schema CREATE 或数据库 CREATE/TEMP 权限。迁移未完成时启动明确失败，不会自动 DDL。

```bash
# 配置并由宿主授权迁移后：
node --env-file=.env examples/server.mjs
```

样例仅监听 `127.0.0.1`，不开日志、不信任转发头。真实部署由已有宿主控制反向代理、TLS、进程生命周期、迁移 runner 和日志脱敏。

所选技术路径是邮箱／密码；**未启用邮箱验证或找回密码，因此不声明证明了邮箱所有权**。默认 `IDENTITY_ALLOW_REGISTRATION=false`。正式开放注册前必须决策 Q-03、邮件验证／账户恢复策略与入口风控。SIWE／钱包签名／企业 SSO／支付权利均不在本版本。

## 宿主集成形状

```ts
import { createIdentityModule, identityPreHandler } from '@hanamesh/server-identity';

const identity = await createIdentityModule({ env: process.env });
await app.register(identity.plugin);

app.get('/my-private-item', {
  preHandler: identityPreHandler(identity.services, {
    action: 'item:read',
    loadResource: async (request, principal) => itemService.loadOwnedCandidate(principal.principalId),
    policy: ({ principal, resource, action }) =>
      action === 'item:read' && resource.ownerPrincipalId === principal.principalId,
  }),
}, async () => ({ ok: true }));
```

`app`／`itemService` 是宿主已有对象；上段为接口使用形状，不是假装知道未读取的宿主具体 API。身份依赖缺失时 `identityPreHandler(undefined, ...)` 直接抛错，不能降级为公开路由。

`createIdentityModule` 返回 plugin、services、close，**不返回 auth 实例、原始会话或 DB pool**。自己创建的 pool 自己关闭；传入宿主 pool 时只借用、不关闭宿主 pool。

### 跨模块事务：先验证，再用宿主事务写

```ts
const actor = await identity.services.authenticate({ cookie: request.headers.cookie });
const connection = await hostPool.connect();
try {
  await connection.query('BEGIN');
  await identity.services.updateOwnProfile(actor, { displayName: 'Hana' }, { executor: connection });
  await anotherService.writeSomething(data, { executor: connection });
  await connection.query('COMMIT');
  // 在 COMMIT 成功以后才向调用者宣布跨模块写入成功。
} catch (error) {
  await connection.query('ROLLBACK');
  throw error;
} finally {
  connection.release();
}
```

`executor` 必须是已 BEGIN、同一数据库、固定连接的执行器，不是连接池，更不是客户端传入的 JSON。传入后本模块不另开连接，不 BEGIN／COMMIT／ROLLBACK／release。`VerifiedActor` 是当前进程当前请求使用的短期凭证（最长 30 秒且不超过会话到期）；不可序列化、跨请求缓存或用在排队任务中。会话验证放在打开宿主事务之前，不能把跨框架认证库硬塞进未知宿主事务。

## 目录入口

| 文件／目录 | 用途 |
|---|---|
| `src/` | 完整候选实现；`contracts.ts` 可供浏览器类型消费 |
| `migrations/0000_identity.sql` | 本模块七张表；宿主迁移 runner 执行 |
| `src/database/schema.ts` | 对应 Drizzle schema；只含本模块模型 |
| `test/` | 离线 tests 与真实验收工具，清楚区分证据 |
| `consistency.json` | 两组原子事实、两个跨介质顺序边界 |
| `docs/API.md`、`docs/SECURITY.md` | 对外契约、安全与部署约束 |
| `docs/acceptance/AC-24.md` | I01–I15、X01–X03 的本次真实状态 |
| `docs/handoff/` | 继续执行指令、GitHub情况、仅修改本模块的 STATUS patch |
| `artifacts/` | 本次测试原始结果、环境记录、tarball 与摘要、Git bundle |

ZIP 内的 `artifacts/package-manifest.json` 记录 npm tarball 的 SHA-256；`FILES.sha256` 记录 ZIP 内容校验。tarball 可供后续锁定安装，但**不代表其依赖或宿主整合已验收**。

## GitHub

本次确认连接账户是 `yzsnstotz`，但连接器没有创建仓库操作，且目标薄宿主读取返回 404；没有改动任何已有远端。`scripts/publish-github.sh` 是供已授权本机执行的私有仓库创建脚本，不会自动执行。脚本校验账户、干净本地提交和不存在 origin，拒绝换用其他仓库。

ZIP 不包含 `.git`；可以从随包 `artifacts/hanamesh-server-identity.bundle` 恢复本地提交历史后继续工作，或者自行 `git init` 并审查后提交。恢复说明见 `docs/handoff/GITHUB.md`。
